function tupian(){
	

}// JavaScript Document